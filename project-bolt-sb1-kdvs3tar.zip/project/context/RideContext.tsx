import { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { availableDrivers as mockDrivers, activeRide as mockRide } from '@/data/mockData';

interface RideRequest {
  pickup: string;
  destination: string;
  seats: number;
  notes?: string;
}

interface RideContextType {
  activeRide: any | null;
  availableDrivers: any[];
  rideRequests: any[];
  requestRide: (request: RideRequest) => void;
  acceptRideRequest: (requestId: string) => void;
  completeRide: () => void;
  cancelRide: () => void;
  updateDriverStatus: (isAvailable: boolean) => void;
}

const RideContext = createContext<RideContextType>({
  activeRide: null,
  availableDrivers: [],
  rideRequests: [],
  requestRide: () => {},
  acceptRideRequest: () => {},
  completeRide: () => {},
  cancelRide: () => {},
  updateDriverStatus: () => {},
});

export const useRide = () => useContext(RideContext);

export const RideProvider = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  const [activeRide, setActiveRide] = useState<any | null>(null);
  const [availableDrivers, setAvailableDrivers] = useState<any[]>([]);
  const [rideRequests, setRideRequests] = useState<any[]>([]);
  const [driverAvailable, setDriverAvailable] = useState(false);
  
  useEffect(() => {
    // In a real app, this would fetch data from an API
    // For now, we'll use mock data
    setAvailableDrivers(mockDrivers);
    
    // Simulate an active ride for demo purposes
    if (user) {
      // 50% chance of having an active ride
      const hasActiveRide = Math.random() > 0.5;
      if (hasActiveRide) {
        setActiveRide(mockRide);
      }
    }
  }, [user]);
  
  const requestRide = (request: RideRequest) => {
    // In a real app, this would make an API call to create a ride request
    
    // For demo, simulate a ride being accepted immediately
    const driver = availableDrivers[Math.floor(Math.random() * availableDrivers.length)];
    
    setTimeout(() => {
      setActiveRide({
        id: Math.random().toString(36).substr(2, 9),
        driver: driver,
        passenger: {
          id: user?.id,
          name: user?.name,
          phone: '045-123-456',
        },
        pickup: request.pickup,
        destination: request.destination,
        seats: request.seats,
        price: 3.5, // Mock price
        eta: Math.floor(Math.random() * 10) + 1, // Random ETA between 1-10 minutes
        status: 'accepted',
        createdAt: new Date().toISOString(),
      });
    }, 2000); // Simulate 2-second delay for ride acceptance
  };
  
  const acceptRideRequest = (requestId: string) => {
    // In a real app, this would make an API call to accept a ride request
    const request = rideRequests.find(req => req.id === requestId);
    
    if (request) {
      setActiveRide({
        id: Math.random().toString(36).substr(2, 9),
        driver: {
          id: user?.id,
          name: user?.name,
          car: user?.vehicle,
        },
        passenger: request.passenger,
        pickup: request.pickup,
        destination: request.destination,
        seats: request.seats,
        price: request.price,
        eta: Math.floor(Math.random() * 10) + 1, // Random ETA between 1-10 minutes
        status: 'accepted',
        createdAt: new Date().toISOString(),
      });
      
      // Remove the request from available requests
      setRideRequests(rideRequests.filter(req => req.id !== requestId));
    }
  };
  
  const completeRide = () => {
    // In a real app, this would make an API call to complete a ride
    setActiveRide(null);
  };
  
  const cancelRide = () => {
    // In a real app, this would make an API call to cancel a ride
    setActiveRide(null);
  };
  
  const updateDriverStatus = (isAvailable: boolean) => {
    setDriverAvailable(isAvailable);
    
    // In a real app, this would update the driver's status in the backend
    // For demo purposes, we'll just update the state
  };

  return (
    <RideContext.Provider value={{ 
      activeRide, 
      availableDrivers, 
      rideRequests,
      requestRide, 
      acceptRideRequest, 
      completeRide,
      cancelRide,
      updateDriverStatus,
    }}>
      {children}
    </RideContext.Provider>
  );
};