import { createContext, useContext, useState, useEffect } from 'react';
import { Platform } from 'react-native';

interface Location {
  latitude: number;
  longitude: number;
}

interface LocationContextType {
  location: Location | null;
  error: string | null;
}

const LocationContext = createContext<LocationContextType>({
  location: null,
  error: null,
});

export const useLocation = () => useContext(LocationContext);

export const LocationProvider = ({ children }: { children: React.ReactNode }) => {
  const [location, setLocation] = useState<Location | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Get user's location
    const getLocation = async () => {
      try {
        if (Platform.OS === 'web') {
          // For web, we'll use the browser's geolocation API
          navigator.geolocation.getCurrentPosition(
            (position) => {
              setLocation({
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
              });
            },
            (err) => {
              setError('Failed to get location. Please enable location services.');
              
              // If geolocation fails or is denied, use a default location for Kosovo
              setLocation({
                latitude: 42.6629,
                longitude: 21.1655,
              });
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
          );
          
          // Watch position for real-time updates
          const watchId = navigator.geolocation.watchPosition(
            (position) => {
              setLocation({
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
              });
            },
            (err) => {
              setError('Failed to watch location.');
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
          );
          
          // Clear the watch when component unmounts
          return () => {
            navigator.geolocation.clearWatch(watchId);
          };
        } else {
          // For native platforms, we would use Expo's Location API
          // But for this example, we'll use a mock location for Kosovo
          setLocation({
            latitude: 42.6629,
            longitude: 21.1655,
          });
        }
      } catch (err) {
        setError('Failed to get location. Please try again.');
        
        // Default to a location in Kosovo
        setLocation({
          latitude: 42.6629,
          longitude: 21.1655,
        });
      }
    };

    getLocation();
  }, []);

  return (
    <LocationContext.Provider value={{ location, error }}>
      {children}
    </LocationContext.Provider>
  );
};