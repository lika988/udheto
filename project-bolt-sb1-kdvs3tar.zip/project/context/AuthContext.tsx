import { createContext, useContext, useState, useEffect } from 'react';
import { Alert } from 'react-native';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'driver' | 'passenger';
  vehicle?: {
    model: string;
    color: string;
    plate: string;
    seats: number;
  };
}

interface VehicleInfo {
  model: string;
  color: string;
  plate: string;
  seats: number;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, name: string, role: string) => Promise<boolean>;
  logout: () => void;
  updateVehicleInfo: (vehicle: VehicleInfo) => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => false,
  register: async () => false,
  logout: () => {},
  updateVehicleInfo: () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const checkAuth = async () => {
      try {
        // In a real app, you would check localStorage, AsyncStorage, or a token
        const savedUser = localStorage.getItem('user');
        if (savedUser) {
          setUser(JSON.parse(savedUser));
        }
      } catch (error) {
        console.error('Failed to get auth state', error);
      } finally {
        // Simulate loading delay to show splash screen
        setTimeout(() => {
          setIsLoading(false);
        }, 1000);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // In a real app, you would make an API call to authenticate
      if (email && password) {
        // Mock successful login
        const mockUser: User = {
          id: Math.random().toString(36).substr(2, 9),
          name: email.split('@')[0],
          email,
          role: 'passenger',
        };
        
        setUser(mockUser);
        localStorage.setItem('user', JSON.stringify(mockUser));
        return true;
      }
      
      Alert.alert('Error', 'Invalid email or password');
      return false;
    } catch (error) {
      console.error('Login failed', error);
      Alert.alert('Error', 'Login failed. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (email: string, password: string, name: string, role: string) => {
    setIsLoading(true);
    try {
      // In a real app, you would make an API call to register
      if (email && password && name) {
        // Mock successful registration
        const mockUser: User = {
          id: Math.random().toString(36).substr(2, 9),
          name,
          email,
          role: role === 'driver' ? 'driver' : 'passenger',
        };
        
        setUser(mockUser);
        localStorage.setItem('user', JSON.stringify(mockUser));
        return true;
      }
      
      Alert.alert('Error', 'Please fill in all required fields');
      return false;
    } catch (error) {
      console.error('Registration failed', error);
      Alert.alert('Error', 'Registration failed. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };
  
  const updateVehicleInfo = (vehicle: VehicleInfo) => {
    if (user) {
      const updatedUser = { ...user, vehicle };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      isLoading, 
      login, 
      register, 
      logout,
      updateVehicleInfo
    }}>
      {children}
    </AuthContext.Provider>
  );
};