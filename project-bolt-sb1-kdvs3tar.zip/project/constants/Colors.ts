const Colors = {
  primary: '#3366FF',
  primaryLight: 'rgba(51, 102, 255, 0.1)',
  secondary: '#00C2CB',
  secondaryLight: 'rgba(0, 194, 203, 0.1)',
  accent: '#FF9500',
  accentLight: 'rgba(255, 149, 0, 0.1)',
  success: '#34C759',
  warning: '#FFB800',
  error: '#FF3B30',
  background: '#F7F8FA',
  card: '#FFFFFF',
  text: '#333333',
  textSecondary: '#666666',
  textLight: '#999999',
  border: '#EEEEEE',
};

export default Colors;