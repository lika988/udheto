import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Modal, 
  TouchableOpacity, 
  TextInput,
  ScrollView,
  Platform
} from 'react-native';
import { useRide } from '@/context/RideContext';
import { X, MapPin } from 'lucide-react-native';
import Colors from '@/constants/Colors';

interface RequestRideModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function RequestRideModal({ visible, onClose }: RequestRideModalProps) {
  const { requestRide } = useRide();
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [seats, setSeats] = useState('1');
  const [notes, setNotes] = useState('');
  
  const handleRequest = () => {
    if (pickup && destination) {
      requestRide({
        pickup,
        destination,
        seats: parseInt(seats),
        notes
      });
      onClose();
      
      // Reset form
      setPickup('');
      setDestination('');
      setSeats('1');
      setNotes('');
    }
  };
  
  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Request a Ride</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color="#333" />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.modalContent}>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Pickup Location</Text>
              <View style={styles.inputWrapper}>
                <MapPin size={20} color={Colors.primary} />
                <TextInput
                  style={styles.input}
                  placeholder="Enter pickup location"
                  value={pickup}
                  onChangeText={setPickup}
                />
              </View>
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Destination</Text>
              <View style={styles.inputWrapper}>
                <MapPin size={20} color={Colors.secondary} />
                <TextInput
                  style={styles.input}
                  placeholder="Enter destination"
                  value={destination}
                  onChangeText={setDestination}
                />
              </View>
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Number of Passengers</Text>
              <View style={styles.seatsRow}>
                {[1, 2, 3, 4].map((num) => (
                  <TouchableOpacity
                    key={num}
                    style={[
                      styles.seatButton,
                      parseInt(seats) === num && styles.seatButtonActive,
                    ]}
                    onPress={() => setSeats(num.toString())}
                  >
                    <Text
                      style={[
                        styles.seatButtonText,
                        parseInt(seats) === num && styles.seatButtonTextActive,
                      ]}
                    >
                      {num}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Notes for Driver (Optional)</Text>
              <TextInput
                style={[styles.input, styles.notesInput]}
                placeholder="e.g., I have luggage, specific pickup instructions, etc."
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
            
            <View style={styles.priceEstimate}>
              <Text style={styles.priceEstimateText}>Estimated Price Range:</Text>
              <Text style={styles.priceEstimateAmount}>€2.00 - €3.50</Text>
            </View>
          </ScrollView>
          
          <View style={styles.modalFooter}>
            <TouchableOpacity 
              style={[styles.button, styles.cancelButton]} 
              onPress={onClose}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.button, styles.requestButton]}
              onPress={handleRequest}
              disabled={!pickup || !destination}
            >
              <Text style={styles.requestButtonText}>Request Ride</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '90%',
    paddingBottom: Platform.OS === 'ios' ? 40 : 16,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  closeButton: {
    padding: 4,
  },
  modalContent: {
    padding: 16,
    maxHeight: '70%',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 50,
  },
  input: {
    flex: 1,
    height: 50,
    marginLeft: 8,
    fontSize: 16,
  },
  notesInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingTop: 12,
    minHeight: 80,
  },
  seatsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  seatButton: {
    flex: 1,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  seatButtonActive: {
    backgroundColor: Colors.primaryLight,
    borderColor: Colors.primary,
  },
  seatButtonText: {
    fontSize: 16,
    color: '#666',
  },
  seatButtonTextActive: {
    color: Colors.primary,
    fontWeight: '600',
  },
  priceEstimate: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f7f8fa',
    borderRadius: 8,
    marginTop: 8,
    marginBottom: 16,
  },
  priceEstimateText: {
    fontSize: 14,
    color: '#666',
  },
  priceEstimateAmount: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.primary,
  },
  modalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  button: {
    flex: 1,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  cancelButton: {
    backgroundColor: '#f0f0f0',
  },
  cancelButtonText: {
    color: '#333',
    fontSize: 16,
    fontWeight: '500',
  },
  requestButton: {
    backgroundColor: Colors.primary,
  },
  requestButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
});