import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Check, X, Calendar } from 'lucide-react-native';
import Colors from '@/constants/Colors';

interface RideHistoryCardProps {
  ride: {
    id: string;
    date: string;
    pickup: string;
    destination: string;
    price: number;
    status: 'completed' | 'cancelled';
    partner: {
      name: string;
      role: 'driver' | 'passenger';
    };
  };
}

export default function RideHistoryCard({ ride }: RideHistoryCardProps) {
  const isCompleted = ride.status === 'completed';
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.dateContainer}>
          <Calendar size={14} color="#666" />
          <Text style={styles.dateText}>{ride.date}</Text>
        </View>
        <View 
          style={[
            styles.statusContainer, 
            { backgroundColor: isCompleted ? Colors.successLight : '#FFEBEE' }
          ]}
        >
          {isCompleted ? (
            <Check size={12} color={Colors.success} />
          ) : (
            <X size={12} color={Colors.error} />
          )}
          <Text 
            style={[
              styles.statusText,
              { color: isCompleted ? Colors.success : Colors.error }
            ]}
          >
            {isCompleted ? 'Completed' : 'Cancelled'}
          </Text>
        </View>
      </View>
      
      <View style={styles.routeContainer}>
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, { backgroundColor: Colors.primary }]} />
          <Text style={styles.routeText} numberOfLines={1}>{ride.pickup}</Text>
        </View>
        <View style={styles.routeLine} />
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, { backgroundColor: Colors.secondary }]} />
          <Text style={styles.routeText} numberOfLines={1}>{ride.destination}</Text>
        </View>
      </View>
      
      <View style={styles.footer}>
        <View>
          <Text style={styles.partnerLabel}>
            {ride.partner.role === 'driver' ? 'Driver' : 'Passenger'}
          </Text>
          <Text style={styles.partnerName}>{ride.partner.name}</Text>
        </View>
        <Text style={styles.price}>€{ride.price.toFixed(2)}</Text>
      </View>
      
      {isCompleted && (
        <TouchableOpacity style={styles.reviewButton}>
          <Text style={styles.reviewButtonText}>Leave a Review</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
    marginLeft: 4,
  },
  routeContainer: {
    marginBottom: 16,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  routeMarker: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 12,
  },
  routeLine: {
    width: 2,
    height: 16,
    backgroundColor: '#ddd',
    marginLeft: 4,
    marginBottom: 8,
  },
  routeText: {
    fontSize: 14,
    color: '#333',
    flex: 1,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  partnerLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  partnerName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  price: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.primary,
  },
  reviewButton: {
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  reviewButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
});