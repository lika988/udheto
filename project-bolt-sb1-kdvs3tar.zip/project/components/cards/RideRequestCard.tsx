import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MapPin, Users } from 'lucide-react-native';
import Colors from '@/constants/Colors';

interface RideRequestProps {
  request: {
    id: string;
    passenger: {
      name: string;
      rating: number;
    };
    pickup: string;
    destination: string;
    price: number;
    distance: number;
    seats: number;
  };
  onSelect: () => void;
}

export default function RideRequestCard({ request, onSelect }: RideRequestProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onSelect}>
      <View style={styles.headerRow}>
        <Text style={styles.passengerName}>{request.passenger.name}</Text>
        <Text style={styles.price}>€{request.price.toFixed(2)}</Text>
      </View>
      
      <View style={styles.routeContainer}>
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, { backgroundColor: Colors.primary }]} />
          <Text style={styles.routeText} numberOfLines={1}>{request.pickup}</Text>
        </View>
        <View style={styles.routeLine} />
        <View style={styles.routePoint}>
          <View style={[styles.routeMarker, { backgroundColor: Colors.secondary }]} />
          <Text style={styles.routeText} numberOfLines={1}>{request.destination}</Text>
        </View>
      </View>
      
      <View style={styles.footerRow}>
        <View style={styles.distanceContainer}>
          <MapPin size={14} color="#666" />
          <Text style={styles.distanceText}>{request.distance} km</Text>
        </View>
        
        <View style={styles.seatsContainer}>
          <Users size={14} color="#666" />
          <Text style={styles.seatsText}>
            {request.seats} {request.seats === 1 ? 'passenger' : 'passengers'}
          </Text>
        </View>
        
        <TouchableOpacity 
          style={styles.acceptButton}
          onPress={onSelect}
        >
          <Text style={styles.acceptButtonText}>Accept</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  passengerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  price: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.primary,
  },
  routeContainer: {
    marginBottom: 16,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  routeMarker: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 12,
  },
  routeLine: {
    width: 2,
    height: 16,
    backgroundColor: '#ddd',
    marginLeft: 4,
    marginBottom: 8,
  },
  routeText: {
    fontSize: 14,
    color: '#333',
    flex: 1,
  },
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  distanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  distanceText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  seatsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seatsText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  acceptButton: {
    marginLeft: 'auto',
    backgroundColor: Colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  acceptButtonText: {
    color: 'white',
    fontWeight: '500',
    fontSize: 14,
  },
});