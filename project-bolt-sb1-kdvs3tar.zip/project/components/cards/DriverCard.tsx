import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Star, Car } from 'lucide-react-native';
import Colors from '@/constants/Colors';

interface DriverCardProps {
  driver: {
    id: string;
    name: string;
    rating: number;
    car: {
      model: string;
      color: string;
      plate: string;
    };
    price: number;
    availableSeats: number;
    eta: number;
  };
}

export default function DriverCard({ driver }: DriverCardProps) {
  return (
    <TouchableOpacity style={styles.container}>
      <View style={styles.driverInfo}>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg' }}
          style={styles.avatar}
        />
        <View style={styles.details}>
          <Text style={styles.name}>{driver.name}</Text>
          <View style={styles.ratingContainer}>
            <Star size={14} color="#FFB800" fill="#FFB800" />
            <Text style={styles.rating}>{driver.rating.toFixed(1)}</Text>
          </View>
          <View style={styles.carInfo}>
            <Car size={14} color="#666" />
            <Text style={styles.carText}>
              {driver.car.model} • {driver.car.color}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.priceContainer}>
        <Text style={styles.price}>€{driver.price.toFixed(2)}</Text>
        <View style={styles.etaContainer}>
          <Text style={styles.etaText}>{driver.eta} min away</Text>
        </View>
        <View style={styles.seatsContainer}>
          <Text style={styles.seatsText}>
            {driver.availableSeats} {driver.availableSeats === 1 ? 'seat' : 'seats'}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#ddd',
  },
  details: {
    marginLeft: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  rating: {
    marginLeft: 4,
    fontSize: 14,
    color: '#666',
  },
  carInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  carText: {
    marginLeft: 4,
    fontSize: 12,
    color: '#666',
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  price: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.primary,
    marginBottom: 4,
  },
  etaContainer: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    marginBottom: 4,
  },
  etaText: {
    fontSize: 12,
    color: '#666',
  },
  seatsContainer: {
    backgroundColor: Colors.successLight,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
  },
  seatsText: {
    fontSize: 12,
    color: Colors.success,
  },
});