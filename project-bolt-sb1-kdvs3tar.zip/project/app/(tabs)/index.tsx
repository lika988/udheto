import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Platform } from 'react-native';
import { MapPin, Clock, User } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { useLocation } from '@/context/LocationContext';
import { useRide } from '@/context/RideContext';
import Colors from '@/constants/Colors';
import { rideRequests } from '@/data/mockData';
import RequestRideModal from '@/components/modals/RequestRideModal';
import DriverCard from '@/components/cards/DriverCard';
import RideRequestCard from '@/components/cards/RideRequestCard';
import { StatusBar } from 'expo-status-bar';

// Only import MapView when not on web platform
let MapView: any;
let Marker: any;
if (Platform.OS !== 'web') {
  const Maps = require('react-native-maps');
  MapView = Maps.default;
  Marker = Maps.Marker;
}

export default function MainScreen() {
  const { user } = useAuth();
  const { location } = useLocation();
  const { activeRide, availableDrivers, updateDriverStatus } = useRide();
  const [requestModalVisible, setRequestModalVisible] = useState(false);
  const [selectedRideRequest, setSelectedRideRequest] = useState(null);
  
  const isDriver = user?.role === 'driver';
  
  useEffect(() => {
    if (isDriver) {
      // Set driver as available
      updateDriverStatus(true);
    }
  }, [isDriver]);

  const MapComponent = () => {
    if (Platform.OS === 'web') {
      return (
        <View style={styles.mapContainer}>
          <View style={styles.mapPlaceholder}>
            <MapPin size={32} color={Colors.primary} />
            <Text style={styles.mapText}>Interactive Map View</Text>
            <Text style={styles.mapSubtext}>
              Your current location: {location?.latitude.toFixed(4)}, {location?.longitude.toFixed(4)}
            </Text>
          </View>
        </View>
      );
    }
    
    return (
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: location?.latitude || 42.6629,
          longitude: location?.longitude || 21.1655,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        {location && (
          <Marker
            coordinate={{
              latitude: location.latitude,
              longitude: location.longitude,
            }}
            title="You are here"
          />
        )}
      </MapView>
    );
  };

  // Passenger view
  if (!isDriver) {
    return (
      <View style={styles.container}>
        <StatusBar style="dark" />
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Find a Ride</Text>
          <View style={styles.headerLocation}>
            <MapPin size={16} color="#666" />
            <Text style={styles.headerLocationText}>Prishtinë, Kosovo</Text>
          </View>
        </View>
        
        <MapComponent />
        
        {activeRide ? (
          <View style={styles.activeRideContainer}>
            <Text style={styles.sectionTitle}>Your active ride</Text>
            <View style={styles.activeRideCard}>
              <View style={styles.activeRideHeader}>
                <View style={styles.activeRideInfo}>
                  <Text style={styles.activeRideDriver}>{activeRide.driver.name}</Text>
                  <Text style={styles.activeRideDetails}>
                    {activeRide.driver.car.model} • {activeRide.driver.car.color} • {activeRide.driver.car.plate}
                  </Text>
                </View>
                <Text style={styles.activeRidePrice}>€{activeRide.price}</Text>
              </View>
              
              <View style={styles.routeContainer}>
                <View style={styles.routePoint}>
                  <View style={[styles.routeMarker, { backgroundColor: Colors.primary }]} />
                  <Text style={styles.routeText}>{activeRide.pickup}</Text>
                </View>
                <View style={styles.routeLine} />
                <View style={styles.routePoint}>
                  <View style={[styles.routeMarker, { backgroundColor: Colors.secondary }]} />
                  <Text style={styles.routeText}>{activeRide.destination}</Text>
                </View>
              </View>
              
              <View style={styles.etaContainer}>
                <Clock size={16} color="#666" />
                <Text style={styles.etaText}>Driver arriving in {activeRide.eta} minutes</Text>
              </View>
              
              <TouchableOpacity style={styles.chatButton}>
                <Text style={styles.chatButtonText}>Contact Driver</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.availableDriversContainer}>
            <View style={styles.availableDriversHeader}>
              <Text style={styles.sectionTitle}>Available Drivers</Text>
              <TouchableOpacity 
                style={styles.requestButton}
                onPress={() => setRequestModalVisible(true)}
              >
                <Text style={styles.requestButtonText}>Request Ride</Text>
              </TouchableOpacity>
            </View>
            
            <FlatList
              data={availableDrivers}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => <DriverCard driver={item} />}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.driversList}
            />
          </View>
        )}
        
        <RequestRideModal
          visible={requestModalVisible}
          onClose={() => setRequestModalVisible(false)}
        />
      </View>
    );
  }
  
  // Driver view
  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Ride Requests</Text>
        <View style={styles.headerLocation}>
          <User size={16} color="#666" />
          <Text style={styles.headerLocationText}>Driver Mode</Text>
        </View>
      </View>
      
      <MapComponent />
      
      {activeRide ? (
        <View style={styles.activeRideContainer}>
          <Text style={styles.sectionTitle}>Current Passenger</Text>
          <View style={styles.activeRideCard}>
            <View style={styles.activeRideHeader}>
              <View style={styles.activeRideInfo}>
                <Text style={styles.activeRideDriver}>{activeRide.passenger.name}</Text>
                <Text style={styles.activeRideDetails}>
                  {activeRide.passenger.phone} • {activeRide.seats} {activeRide.seats > 1 ? 'passengers' : 'passenger'}
                </Text>
              </View>
              <Text style={styles.activeRidePrice}>€{activeRide.price}</Text>
            </View>
            
            <View style={styles.routeContainer}>
              <View style={styles.routePoint}>
                <View style={[styles.routeMarker, { backgroundColor: Colors.primary }]} />
                <Text style={styles.routeText}>{activeRide.pickup}</Text>
              </View>
              <View style={styles.routeLine} />
              <View style={styles.routePoint}>
                <View style={[styles.routeMarker, { backgroundColor: Colors.secondary }]} />
                <Text style={styles.routeText}>{activeRide.destination}</Text>
              </View>
            </View>
            
            <View style={styles.buttonRow}>
              <TouchableOpacity style={styles.chatButton}>
                <Text style={styles.chatButtonText}>Contact Passenger</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, styles.completeButton]}
              >
                <Text style={styles.actionButtonText}>Complete Ride</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      ) : (
        <View style={styles.requestsContainer}>
          <Text style={styles.sectionTitle}>Nearby Requests</Text>
          
          <FlatList
            data={rideRequests}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <RideRequestCard
                request={item}
                onSelect={() => setSelectedRideRequest(item)}
              />
            )}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.requestsList}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f8fa',
  },
  header: {
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 16,
    paddingHorizontal: 16,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginBottom: 4,
  },
  headerLocation: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerLocationText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  mapContainer: {
    height: 250,
    marginBottom: 16,
  },
  mapPlaceholder: {
    flex: 1,
    backgroundColor: '#E9ECEF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapText: {
    marginTop: 8,
    fontSize: 16,
    fontWeight: '600',
    color: '#495057',
  },
  mapSubtext: {
    marginTop: 4,
    fontSize: 14,
    color: '#6C757D',
  },
  map: {
    height: 250,
    width: '100%',
  },
  availableDriversContainer: {
    flex: 1,
    padding: 16,
  },
  availableDriversHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  requestButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  requestButtonText: {
    color: 'white',
    fontWeight: '500',
    fontSize: 14,
  },
  driversList: {
    paddingBottom: 24,
  },
  requestsContainer: {
    flex: 1,
    padding: 16,
  },
  requestsList: {
    paddingBottom: 24,
  },
  activeRideContainer: {
    flex: 1,
    padding: 16,
  },
  activeRideCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginTop: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  activeRideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  activeRideInfo: {
    flex: 1,
  },
  activeRideDriver: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  activeRideDetails: {
    fontSize: 14,
    color: '#666',
  },
  activeRidePrice: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.primary,
  },
  routeContainer: {
    marginBottom: 16,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  routeMarker: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  routeLine: {
    width: 2,
    height: 24,
    backgroundColor: '#ddd',
    marginLeft: 5,
    marginBottom: 8,
  },
  routeText: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  etaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    marginBottom: 16,
  },
  etaText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  chatButton: {
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  chatButtonText: {
    color: '#333',
    fontWeight: '500',
    fontSize: 14,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  completeButton: {
    backgroundColor: Colors.primary,
  },
  actionButtonText: {
    color: 'white',
    fontWeight: '500',
    fontSize: 14,
  },
});