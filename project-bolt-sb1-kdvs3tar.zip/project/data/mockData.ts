export const availableDrivers = [
  {
    id: 'driver1',
    name: 'Arben K.',
    rating: 4.8,
    car: {
      model: 'Toyota Corolla',
      color: 'Silver',
      plate: 'KS-123-AB',
    },
    price: 2.50,
    availableSeats: 3,
    eta: 5,
  },
  {
    id: 'driver2',
    name: 'Faton M.',
    rating: 4.6,
    car: {
      model: 'Honda Civic',
      color: 'Black',
      plate: 'KS-456-CD',
    },
    price: 3.00,
    availableSeats: 4,
    eta: 3,
  },
  {
    id: 'driver3',
    name: 'Drita N.',
    rating: 4.9,
    car: {
      model: 'Volkswagen Golf',
      color: 'Blue',
      plate: 'KS-789-EF',
    },
    price: 2.75,
    availableSeats: 2,
    eta: 7,
  },
  {
    id: 'driver4',
    name: 'Blerim G.',
    rating: 4.5,
    car: {
      model: 'Skoda Octavia',
      color: 'White',
      plate: 'KS-321-GH',
    },
    price: 2.25,
    availableSeats: 4,
    eta: 10,
  },
];

export const rideRequests = [
  {
    id: 'request1',
    passenger: {
      id: 'passenger1',
      name: 'Lulzim B.',
      rating: 4.7,
    },
    pickup: 'Fushë Kosovë, Train Station',
    destination: 'Prishtinë, Grand Hotel',
    price: 3.50,
    distance: 6.2,
    seats: 1,
  },
  {
    id: 'request2',
    passenger: {
      id: 'passenger2',
      name: 'Valmira R.',
      rating: 4.9,
    },
    pickup: 'Prishtinë, City Stadium',
    destination: 'Prishtinë, University Campus',
    price: 2.50,
    distance: 4.1,
    seats: 2,
  },
  {
    id: 'request3',
    passenger: {
      id: 'passenger3',
      name: 'Gezim K.',
      rating: 4.5,
    },
    pickup: 'Prishtinë, Mother Teresa Street',
    destination: 'Fushë Kosovë, Shopping Mall',
    price: 3.00,
    distance: 5.5,
    seats: 3,
  },
];

export const activeRide = {
  id: 'ride1',
  driver: {
    id: 'driver1',
    name: 'Arben K.',
    rating: 4.8,
    car: {
      model: 'Toyota Corolla',
      color: 'Silver',
      plate: 'KS-123-AB',
    },
  },
  passenger: {
    id: 'passenger1',
    name: 'Lulzim B.',
    phone: '045-123-456',
  },
  pickup: 'Fushë Kosovë, Train Station',
  destination: 'Prishtinë, Grand Hotel',
  price: 3.50,
  seats: 1,
  eta: 5, // minutes
  status: 'accepted',
  createdAt: '2025-05-15T12:30:00Z',
};

export const rideHistory = [
  {
    id: 'history1',
    date: 'Today, 14:30',
    pickup: 'Prishtinë, Bill Clinton Boulevard',
    destination: 'Prishtinë, City Stadium',
    price: 2.00,
    status: 'completed',
    partner: {
      name: 'Arben K.',
      role: 'driver',
    },
  },
  {
    id: 'history2',
    date: 'Yesterday, 09:15',
    pickup: 'Fushë Kosovë, Train Station',
    destination: 'Prishtinë, Mother Teresa Street',
    price: 3.50,
    status: 'completed',
    partner: {
      name: 'Faton M.',
      role: 'driver',
    },
  },
  {
    id: 'history3',
    date: '15 May, 18:20',
    pickup: 'Prishtinë, University Campus',
    destination: 'Prishtinë, Newborn Monument',
    price: 2.25,
    status: 'cancelled',
    partner: {
      name: 'Drita N.',
      role: 'driver',
    },
  },
  {
    id: 'history4',
    date: '12 May, 11:00',
    pickup: 'Prishtinë, Grand Hotel',
    destination: 'Fushë Kosovë, Shopping Mall',
    price: 4.00,
    status: 'completed',
    partner: {
      name: 'Blerim G.',
      role: 'driver',
    },
  },
  {
    id: 'history5',
    date: '10 May, 20:45',
    pickup: 'Prishtinë, Sunny Hill',
    destination: 'Prishtinë, City Center',
    price: 2.75,
    status: 'completed',
    partner: {
      name: 'Arben K.',
      role: 'driver',
    },
  },
];

export const conversations = [
  {
    id: 'conv1',
    user: {
      id: 'user1',
      name: 'Arben K.',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    },
    lastMessage: {
      text: 'I am near the entrance, blue Toyota',
      timestamp: '14:30',
    },
    unread: 2,
    messages: [
      {
        text: 'Hello, I am on my way to pick you up',
        timestamp: '14:25',
        senderId: 'user1',
      },
      {
        text: 'Great! I\'ll be waiting at the entrance',
        timestamp: '14:26',
        senderId: 'currentUser',
      },
      {
        text: 'I am near the entrance, blue Toyota',
        timestamp: '14:30',
        senderId: 'user1',
      },
    ],
  },
  {
    id: 'conv2',
    user: {
      id: 'user2',
      name: 'Valmira R.',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    },
    lastMessage: {
      text: 'Thank you for the ride!',
      timestamp: 'Yesterday',
    },
    unread: 0,
    messages: [
      {
        text: 'I\'m at the pickup location',
        timestamp: 'Yesterday, 18:30',
        senderId: 'currentUser',
      },
      {
        text: 'Coming in 2 minutes',
        timestamp: 'Yesterday, 18:31',
        senderId: 'user2',
      },
      {
        text: 'Thank you for the ride!',
        timestamp: 'Yesterday, 19:15',
        senderId: 'user2',
      },
    ],
  },
];